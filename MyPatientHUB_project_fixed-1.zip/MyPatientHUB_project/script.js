// Login
const signInBtn = document.getElementById("signInBtn");
if (signInBtn) {
  signInBtn.addEventListener("click", function () {
    window.location.href = "dashboard.html";
  });
}

const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
      alert("Please enter your email/phone and password.");
      return;
    }

    localStorage.setItem("myPatientUser", email);
    window.location.href = "dashboard.html";
  });
}

const signupBtn = document.getElementById("signupBtn");
if (signupBtn) {
  signupBtn.addEventListener("click", () => {
    alert("Sign up page can be connected here.");
  });
}

// Dashboard sidebar
const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("sidebar");
if (menuBtn && sidebar) {
  menuBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
  });
}

// Logout
document.querySelectorAll(".top-actions button").forEach(btn => {
  if (btn.textContent.toLowerCase().includes("log out")) {
    btn.addEventListener("click", () => {
      localStorage.removeItem("myPatientUser");
      window.location.href = "index.html";
    });
  }
});

// Sidebar active menu
document.querySelectorAll(".sidebar nav a").forEach(link => {
  link.addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelectorAll(".sidebar nav a").forEach(x => x.classList.remove("active"));
    this.classList.add("active");
  });
});
